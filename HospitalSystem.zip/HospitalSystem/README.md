# MediCare Hospital Admission System

A simple console-based Java program for PROG6112 Practical Assignment 1.
Written in plain, beginner-friendly Java: fixed-size arrays, counters, if/else,
and simple loops - no ArrayList, no streams, no lambdas, no shortcuts.

## What's inside (and what it maps to on the rubric)

| File | What it does | Rubric feature |
|---|---|---|
| `PatientCategory.java` | The 3 allowed patient types (enum) | Feature 4 |
| `Patient.java` | Base patient class | Feature 1 |
| `Inpatient.java` | Extends Patient, adds ward/bed info | Feature 4 |
| `Bed.java` | One single bed | Feature 2 |
| `Ward.java` | The 20-bed, 4x5 grid (plain array) | Feature 2 |
| `HospitalService.java` | All the business rules/logic (plain array + counter) | Features 1, 2, 3 |
| `Main.java` | The console menu you interact with | Menu-driven requirement |
| `HospitalServiceTest.java` (in `src/test`) | JUnit tests | Feature 5 |

## How to open and run it in VS Code

1. Install the "Extension Pack for Java" (by Microsoft) from the Extensions tab.
2. Make sure a full JDK (version 17 or higher) is installed, not just a JRE.
3. File > Open Folder > select the `HospitalSystem` folder (the one with `pom.xml`).
4. Wait for VS Code to detect the Maven project and download JUnit (needs internet once).
5. Open `Main.java`, click the "Run" button above `public static void main`.
6. Open `HospitalServiceTest.java`, click the green play icons next to each test to run them.

## Notes on the code style
- Patients are stored in a plain array (`Patient[]`) with a counter (`patientCount`),
  not an ArrayList. This is closer to what first-year Java courses teach first.
- Sorting is done with a simple bubble sort (compare neighbours, swap if needed),
  not a built-in sort method.
- All conditions use plain `if / else` - no compact one-line tricks.
- Everything is stored in memory only, as the assignment requires - nothing is saved
  to a file, so data resets every time you restart the program.
