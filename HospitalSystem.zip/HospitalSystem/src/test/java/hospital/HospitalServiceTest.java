package hospital;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

// These are automatic checker tests.
// Each test sets up a small situation and checks the answer is correct.
class HospitalServiceTest {

    private HospitalService service;

    // This runs before every single test, so each test starts fresh.
    @BeforeEach
    void setUp() {
        service = new HospitalService();
    }

    @Test
    void testRegisterPatient() {
        Patient p = new Patient("P001", "John", "Smith", 30, "Male", "Flu", PatientCategory.OUTPATIENT);
        boolean result = service.registerPatient(p);
        assertTrue(result);
        assertEquals(1, service.getTotalPatients());
    }

    @Test
    void testSearchForPatient() {
        Patient p = new Patient("P002", "Jane", "Doe", 25, "Female", "Headache", PatientCategory.EMERGENCY);
        service.registerPatient(p);
        Patient found = service.findPatientById("P002");
        assertNotNull(found);
        assertEquals("Jane", found.getFirstName());
    }

    @Test
    void testUpdatePatientDetails() {
        Patient p = new Patient("P003", "Bob", "Jones", 40, "Male", "Cough", PatientCategory.OUTPATIENT);
        service.registerPatient(p);
        boolean updated = service.updatePatient("P003", "Bob", "Jones", 41, "Male", "Recovered");
        assertTrue(updated);
        assertEquals("Recovered", service.findPatientById("P003").getMedicalCondition());
        assertEquals(41, service.findPatientById("P003").getAge());
    }

    @Test
    void testDeletePatient() {
        Patient p = new Patient("P004", "Amy", "Lee", 22, "Female", "Cold", PatientCategory.OUTPATIENT);
        service.registerPatient(p);
        boolean deleted = service.deletePatient("P004");
        assertTrue(deleted);
        assertNull(service.findPatientById("P004"));
    }

    @Test
    void testAllocateBedToInpatient() {
        String result = service.registerInpatient("P005", "Sam", "Brown", 50, "Male", "Surgery");
        assertTrue(result.startsWith("SUCCESS"));
        assertEquals(1, service.getWard().countOccupied());

        Patient p = service.findPatientById("P005");
        assertTrue(p instanceof Inpatient);
        Inpatient inpatient = (Inpatient) p;
        assertEquals("B01", inpatient.getBedNumber());
    }

    @Test
    void testReleaseBed() {
        service.registerInpatient("P006", "Tim", "Field", 35, "Male", "Fracture");
        boolean released = service.releaseBed("B01");
        assertTrue(released);
        assertEquals(0, service.getWard().countOccupied());
    }

    @Test
    void testPreventDuplicatePatientIds() {
        Patient p1 = new Patient("P007", "Nina", "Cole", 28, "Female", "Fever", PatientCategory.OUTPATIENT);
        Patient p2 = new Patient("P007", "Other", "Person", 99, "Male", "Different", PatientCategory.EMERGENCY);
        assertTrue(service.registerPatient(p1));
        assertFalse(service.registerPatient(p2));
        assertEquals(1, service.getTotalPatients());
    }

    @Test
    void testPreventAllocatingAlreadyOccupiedBed() {
        service.registerInpatient("P008", "First", "Patient", 30, "Male", "Test");
        Bed bed = service.getWard().findBedByNumber("B01");
        assertTrue(bed.isOccupied());

        service.registerInpatient("P009", "Second", "Patient", 31, "Female", "Test2");
        Inpatient second = (Inpatient) service.findPatientById("P009");
        assertNotEquals("B01", second.getBedNumber());
        assertEquals("B02", second.getBedNumber());
    }

    @Test
    void testPreventBedAllocationWhenAllBedsAreOccupied() {
        for (int i = 1; i <= 20; i++) {
            String result = service.registerInpatient("ID" + i, "First" + i, "Last" + i, 30, "Male", "Condition");
            assertTrue(result.startsWith("SUCCESS"));
        }
        assertTrue(service.getWard().isFull());

        String result = service.registerInpatient("ID21", "Extra", "Person", 30, "Male", "Condition");
        assertTrue(result.startsWith("ERROR"));
        assertEquals(20, service.getTotalPatients());
    }

    @Test
    void testSortPatientsBySurname() {
        service.registerPatient(new Patient("P010", "A", "Zebra", 20, "M", "x", PatientCategory.OUTPATIENT));
        service.registerPatient(new Patient("P011", "B", "Apple", 20, "M", "x", PatientCategory.OUTPATIENT));
        Patient[] sorted = service.getPatientsSortedBySurname();
        assertEquals("Apple", sorted[0].getLastName());
        assertEquals("Zebra", sorted[1].getLastName());
    }

    @Test
    void testSortPatientsById() {
        service.registerPatient(new Patient("P020", "A", "One", 20, "M", "x", PatientCategory.OUTPATIENT));
        service.registerPatient(new Patient("P010", "B", "Two", 20, "M", "x", PatientCategory.OUTPATIENT));
        Patient[] sorted = service.getPatientsSortedById();
        assertEquals("P010", sorted[0].getPatientId());
        assertEquals("P020", sorted[1].getPatientId());
    }
}
