package hospital;

import java.util.Scanner;

// This is the program you run. It shows a text menu, reads what you type,
// and calls HospitalService to do the actual work.
public class Main {

    private static Scanner scanner = new Scanner(System.in);
    private static HospitalService service = new HospitalService();

    public static void main(String[] args) {
        boolean running = true;

        while (running) {
            printMenu();
            String choice = scanner.nextLine().trim();

            if (choice.equals("1")) {
                registerPatientMenu();
            } else if (choice.equals("2")) {
                searchPatientMenu();
            } else if (choice.equals("3")) {
                updatePatientMenu();
            } else if (choice.equals("4")) {
                deletePatientMenu();
            } else if (choice.equals("5")) {
                displayAllPatients();
            } else if (choice.equals("6")) {
                allocateBedMenu();
            } else if (choice.equals("7")) {
                releaseBedMenu();
            } else if (choice.equals("8")) {
                service.getWard().printLayout();
            } else if (choice.equals("9")) {
                displayAvailableBeds();
            } else if (choice.equals("10")) {
                displayOccupiedBeds();
            } else if (choice.equals("11")) {
                printReports();
            } else if (choice.equals("0")) {
                running = false;
                System.out.println("Goodbye!");
            } else {
                System.out.println("Invalid option, please try again.");
            }
        }

        scanner.close();
    }

    private static void printMenu() {
        System.out.println("");
        System.out.println("===== MediCare Hospital Admission System =====");
        System.out.println("1. Register a new patient");
        System.out.println("2. Search for a patient");
        System.out.println("3. Update a patient's details");
        System.out.println("4. Delete a patient");
        System.out.println("5. Display all registered patients");
        System.out.println("6. Allocate a bed to an inpatient");
        System.out.println("7. Release a bed (discharge)");
        System.out.println("8. Display ward layout");
        System.out.println("9. Display available beds");
        System.out.println("10. Display occupied beds");
        System.out.println("11. Display reports");
        System.out.println("0. Exit");
        System.out.print("Choose an option: ");
    }

    private static void registerPatientMenu() {
        System.out.print("Patient ID: ");
        String id = scanner.nextLine().trim();

        System.out.print("First name: ");
        String firstName = scanner.nextLine().trim();

        System.out.print("Last name: ");
        String lastName = scanner.nextLine().trim();

        int age = readInt("Age: ");

        System.out.print("Gender: ");
        String gender = scanner.nextLine().trim();

        System.out.print("Medical condition: ");
        String condition = scanner.nextLine().trim();

        System.out.print("Category (1 = Inpatient, 2 = Outpatient, 3 = Emergency): ");
        String categoryChoice = scanner.nextLine().trim();

        if (categoryChoice.equals("1")) {
            String result = service.registerInpatient(id, firstName, lastName, age, gender, condition);
            System.out.println(result);
        } else {
            PatientCategory category;
            if (categoryChoice.equals("3")) {
                category = PatientCategory.EMERGENCY;
            } else {
                category = PatientCategory.OUTPATIENT;
            }
            Patient patient = new Patient(id, firstName, lastName, age, gender, condition, category);
            boolean success = service.registerPatient(patient);
            if (success == true) {
                System.out.println("SUCCESS: Patient registered.");
            } else {
                System.out.println("ERROR: A patient with that ID already exists.");
            }
        }
    }

    private static void searchPatientMenu() {
        System.out.print("Enter Patient ID to search: ");
        String id = scanner.nextLine().trim();
        Patient p = service.findPatientById(id);
        if (p == null) {
            System.out.println("No patient found with that ID.");
        } else {
            System.out.println(p.displayDetails());
        }
    }

    private static void updatePatientMenu() {
        System.out.print("Enter Patient ID to update: ");
        String id = scanner.nextLine().trim();

        if (service.patientIdExists(id) == false) {
            System.out.println("No patient found with that ID.");
            return;
        }

        System.out.print("New first name: ");
        String firstName = scanner.nextLine().trim();

        System.out.print("New last name: ");
        String lastName = scanner.nextLine().trim();

        int age = readInt("New age: ");

        System.out.print("New gender: ");
        String gender = scanner.nextLine().trim();

        System.out.print("New medical condition: ");
        String condition = scanner.nextLine().trim();

        boolean success = service.updatePatient(id, firstName, lastName, age, gender, condition);
        if (success == true) {
            System.out.println("SUCCESS: Patient updated.");
        } else {
            System.out.println("ERROR: Update failed.");
        }
    }

    private static void deletePatientMenu() {
        System.out.print("Enter Patient ID to delete: ");
        String id = scanner.nextLine().trim();
        boolean success = service.deletePatient(id);
        if (success == true) {
            System.out.println("SUCCESS: Patient deleted.");
        } else {
            System.out.println("ERROR: No patient found with that ID.");
        }
    }

    private static void displayAllPatients() {
        Patient[] all = service.getAllPatients();
        if (all.length == 0) {
            System.out.println("No patients registered yet.");
            return;
        }
        System.out.println("");
        System.out.println("--- All Registered Patients ---");
        for (int i = 0; i < all.length; i++) {
            System.out.println(all[i].displayDetails());
        }
    }

    private static void allocateBedMenu() {
        System.out.print("Enter Patient ID (must already be a registered Inpatient): ");
        String id = scanner.nextLine().trim();
        Patient p = service.findPatientById(id);

        if (p == null) {
            System.out.println("ERROR: No patient found with that ID.");
        } else if (p instanceof Inpatient == false) {
            System.out.println("ERROR: Only inpatients may be allocated a bed.");
        } else {
            Inpatient inpatient = (Inpatient) p;
            System.out.println("This inpatient already has bed " + inpatient.getBedNumber() + ".");
        }
    }

    private static void releaseBedMenu() {
        System.out.print("Enter bed number to release (example: B01): ");
        String bedNumber = scanner.nextLine().trim();
        boolean success = service.releaseBed(bedNumber);
        if (success == true) {
            System.out.println("SUCCESS: Bed " + bedNumber + " released.");
        } else {
            System.out.println("ERROR: Bed not found or already empty.");
        }
    }

    private static void displayAvailableBeds() {
        Bed[] beds = service.getWard().getAvailableBeds();
        System.out.println("");
        System.out.println("Available beds (" + beds.length + "): ");
        for (int i = 0; i < beds.length; i++) {
            System.out.print(beds[i].getBedNumber() + "  ");
        }
        System.out.println("");
    }

    private static void displayOccupiedBeds() {
        Bed[] beds = service.getWard().getOccupiedBeds();
        System.out.println("");
        System.out.println("Occupied beds (" + beds.length + "): ");
        for (int i = 0; i < beds.length; i++) {
            System.out.print(beds[i].getBedNumber() + "  ");
        }
        System.out.println("");
    }

    private static void printReports() {
        System.out.println("");
        System.out.println("--- Ward Reports ---");
        System.out.println("Total registered patients: " + service.getTotalPatients());
        System.out.println("Total occupied beds: " + service.getTotalOccupiedBeds() + " / " + Ward.TOTAL_BEDS);
        System.out.println("Ward occupancy: " + service.getOccupancyPercentage() + "%");
    }

    private static int readInt(String prompt) {
        while (true) {
            System.out.print(prompt);
            String input = scanner.nextLine().trim();
            try {
                int value = Integer.parseInt(input);
                return value;
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid whole number.");
            }
        }
    }
}
