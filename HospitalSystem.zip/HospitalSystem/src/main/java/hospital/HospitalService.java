package hospital;

// This class holds the list of patients and the ward.
// It contains all the rules: no duplicate IDs, only inpatients get beds,
// and no bed allocation when the ward is full.
public class HospitalService {

    public static final int MAX_PATIENTS = 100;

    private Patient[] patients;
    private int patientCount;
    private Ward ward;

    public HospitalService() {
        patients = new Patient[MAX_PATIENTS];
        patientCount = 0;
        ward = new Ward();
    }

    public Ward getWard() {
        return ward;
    }

    public boolean patientIdExists(String id) {
        if (findPatientById(id) == null) {
            return false;
        } else {
            return true;
        }
    }

    public Patient findPatientById(String id) {
        for (int i = 0; i < patientCount; i++) {
            if (patients[i].getPatientId().equalsIgnoreCase(id)) {
                return patients[i];
            }
        }
        return null;
    }

    // Registers a plain patient (Outpatient or Emergency).
    public boolean registerPatient(Patient patient) {
        if (patientIdExists(patient.getPatientId())) {
            return false;
        }
        if (patientCount >= MAX_PATIENTS) {
            return false;
        }
        patients[patientCount] = patient;
        patientCount = patientCount + 1;
        return true;
    }

    // Registers an inpatient and automatically gives them the first free bed.
    public String registerInpatient(String id, String firstName, String lastName, int age,
                                     String gender, String condition) {
        if (patientIdExists(id)) {
            return "ERROR: A patient with ID " + id + " already exists.";
        }
        if (patientCount >= MAX_PATIENTS) {
            return "ERROR: Patient list is full.";
        }
        Bed freeBed = ward.findFirstAvailableBed();
        if (freeBed == null) {
            return "ERROR: No beds available. Cannot register a new inpatient.";
        }
        Inpatient inpatient = new Inpatient(id, firstName, lastName, age, gender, condition,
                                             "1", freeBed.getBedNumber());
        patients[patientCount] = inpatient;
        patientCount = patientCount + 1;
        freeBed.occupy(inpatient);
        return "SUCCESS: Inpatient registered and assigned bed " + freeBed.getBedNumber() + ".";
    }

    public boolean updatePatient(String id, String firstName, String lastName, int age,
                                  String gender, String condition) {
        Patient p = findPatientById(id);
        if (p == null) {
            return false;
        }
        p.setFirstName(firstName);
        p.setLastName(lastName);
        p.setAge(age);
        p.setGender(gender);
        p.setMedicalCondition(condition);
        return true;
    }

    // Deletes a patient. If the patient was an inpatient, their bed is freed too.
    public boolean deletePatient(String id) {
        int foundIndex = -1;
        for (int i = 0; i < patientCount; i++) {
            if (patients[i].getPatientId().equalsIgnoreCase(id)) {
                foundIndex = i;
            }
        }

        if (foundIndex == -1) {
            return false;
        }

        Patient p = patients[foundIndex];
        if (p instanceof Inpatient) {
            Inpatient inpatient = (Inpatient) p;
            Bed bed = ward.findBedByNumber(inpatient.getBedNumber());
            if (bed != null) {
                bed.release();
            }
        }

        // Shift every patient after foundIndex one place to the left,
        // so there is no empty gap left in the array.
        for (int i = foundIndex; i < patientCount - 1; i++) {
            patients[i] = patients[i + 1];
        }
        patients[patientCount - 1] = null;
        patientCount = patientCount - 1;

        return true;
    }

    // Returns a plain array with only the real patients in it (no empty slots).
    public Patient[] getAllPatients() {
        Patient[] result = new Patient[patientCount];
        for (int i = 0; i < patientCount; i++) {
            result[i] = patients[i];
        }
        return result;
    }

    // Simple bubble sort by surname. Bubble sort compares two neighbours
    // at a time and swaps them if they are in the wrong order.
    public Patient[] getPatientsSortedBySurname() {
        Patient[] sorted = getAllPatients();

        for (int i = 0; i < sorted.length - 1; i++) {
            for (int j = 0; j < sorted.length - 1 - i; j++) {
                String nameOne = sorted[j].getLastName().toLowerCase();
                String nameTwo = sorted[j + 1].getLastName().toLowerCase();
                if (nameOne.compareTo(nameTwo) > 0) {
                    Patient temp = sorted[j];
                    sorted[j] = sorted[j + 1];
                    sorted[j + 1] = temp;
                }
            }
        }
        return sorted;
    }

    // Simple bubble sort by Patient ID.
    public Patient[] getPatientsSortedById() {
        Patient[] sorted = getAllPatients();

        for (int i = 0; i < sorted.length - 1; i++) {
            for (int j = 0; j < sorted.length - 1 - i; j++) {
                String idOne = sorted[j].getPatientId().toLowerCase();
                String idTwo = sorted[j + 1].getPatientId().toLowerCase();
                if (idOne.compareTo(idTwo) > 0) {
                    Patient temp = sorted[j];
                    sorted[j] = sorted[j + 1];
                    sorted[j + 1] = temp;
                }
            }
        }
        return sorted;
    }

    public boolean releaseBed(String bedNumber) {
        Bed bed = ward.findBedByNumber(bedNumber);
        if (bed == null) {
            return false;
        }
        if (bed.isOccupied() == false) {
            return false;
        }
        bed.release();
        return true;
    }

    public int getTotalPatients() {
        return patientCount;
    }

    public int getTotalOccupiedBeds() {
        return ward.countOccupied();
    }

    public double getOccupancyPercentage() {
        double occupied = ward.countOccupied();
        double total = Ward.TOTAL_BEDS;
        return (occupied * 100.0) / total;
    }
}
