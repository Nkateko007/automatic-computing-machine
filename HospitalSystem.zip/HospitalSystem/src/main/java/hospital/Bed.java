package hospital;

// This class represents one single bed in the ward.
public class Bed {

    private String bedNumber;
    private Inpatient occupant;

    public Bed(String bedNumber) {
        this.bedNumber = bedNumber;
        this.occupant = null;
    }

    public String getBedNumber() {
        return bedNumber;
    }

    // Returns true if a patient is using this bed, false if it is empty.
    public boolean isOccupied() {
        if (occupant == null) {
            return false;
        } else {
            return true;
        }
    }

    public Inpatient getOccupant() {
        return occupant;
    }

    public void occupy(Inpatient patient) {
        occupant = patient;
    }

    public void release() {
        occupant = null;
    }
}
