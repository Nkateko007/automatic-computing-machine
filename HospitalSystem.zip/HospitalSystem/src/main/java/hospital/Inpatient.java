package hospital;

// An Inpatient is a special kind of Patient.
// It has everything a normal Patient has, plus a ward number and a bed number.
// The keyword "extends" means Inpatient gets everything from Patient automatically.
public class Inpatient extends Patient {

    private String wardNumber;
    private String bedNumber;

    public Inpatient(String patientId, String firstName, String lastName, int age,
                      String gender, String medicalCondition,
                      String wardNumber, String bedNumber) {
        // "super" calls the Patient constructor to set up the normal fields first.
        super(patientId, firstName, lastName, age, gender, medicalCondition, PatientCategory.INPATIENT);
        this.wardNumber = wardNumber;
        this.bedNumber = bedNumber;
    }

    public String getWardNumber() {
        return wardNumber;
    }

    public String getBedNumber() {
        return bedNumber;
    }

    public void setBedNumber(String bedNumber) {
        this.bedNumber = bedNumber;
    }

    // "@Override" means we are replacing the Patient version of this method
    // with our own version that also shows ward and bed details.
    @Override
    public String displayDetails() {
        String text = super.displayDetails();
        text = text + " | Ward: " + wardNumber + " | Bed: " + bedNumber;
        return text;
    }
}
