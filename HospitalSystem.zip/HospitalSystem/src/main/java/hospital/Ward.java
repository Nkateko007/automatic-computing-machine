package hospital;

// This class represents the whole ward: 20 beds arranged in a 4 x 5 grid.
public class Ward {

    public static final int TOTAL_BEDS = 20;
    public static final int ROWS = 4;
    public static final int COLUMNS = 5;

    private Bed[] beds;

    public Ward() {
        beds = new Bed[TOTAL_BEDS];
        for (int i = 0; i < TOTAL_BEDS; i++) {
            int number = i + 1;
            String label;
            if (number < 10) {
                label = "B0" + number;
            } else {
                label = "B" + number;
            }
            beds[i] = new Bed(label);
        }
    }

    // Looks through all beds and returns the first empty one.
    // Returns null if every bed is full.
    public Bed findFirstAvailableBed() {
        for (int i = 0; i < beds.length; i++) {
            if (beds[i].isOccupied() == false) {
                return beds[i];
            }
        }
        return null;
    }

    public Bed findBedByNumber(String bedNumber) {
        for (int i = 0; i < beds.length; i++) {
            if (beds[i].getBedNumber().equalsIgnoreCase(bedNumber)) {
                return beds[i];
            }
        }
        return null;
    }

    // Counts how many beds are occupied.
    public int countOccupied() {
        int count = 0;
        for (int i = 0; i < beds.length; i++) {
            if (beds[i].isOccupied() == true) {
                count = count + 1;
            }
        }
        return count;
    }

    public boolean isFull() {
        if (countOccupied() == TOTAL_BEDS) {
            return true;
        } else {
            return false;
        }
    }

    // Returns an array with only the available beds in it.
    public Bed[] getAvailableBeds() {
        int count = 0;
        for (int i = 0; i < beds.length; i++) {
            if (beds[i].isOccupied() == false) {
                count = count + 1;
            }
        }

        Bed[] result = new Bed[count];
        int position = 0;
        for (int i = 0; i < beds.length; i++) {
            if (beds[i].isOccupied() == false) {
                result[position] = beds[i];
                position = position + 1;
            }
        }
        return result;
    }

    // Returns an array with only the occupied beds in it.
    public Bed[] getOccupiedBeds() {
        int count = 0;
        for (int i = 0; i < beds.length; i++) {
            if (beds[i].isOccupied() == true) {
                count = count + 1;
            }
        }

        Bed[] result = new Bed[count];
        int position = 0;
        for (int i = 0; i < beds.length; i++) {
            if (beds[i].isOccupied() == true) {
                result[position] = beds[i];
                position = position + 1;
            }
        }
        return result;
    }

    // Prints the ward as a 4 x 5 grid, like in the assignment brief.
    public void printLayout() {
        System.out.println("");
        System.out.println("--- Ward Layout (4 x 5) ---");
        int index = 0;
        for (int row = 0; row < ROWS; row++) {
            String line = "";
            for (int col = 0; col < COLUMNS; col++) {
                Bed bed = beds[index];
                String marker;
                if (bed.isOccupied() == true) {
                    marker = "[X]";
                } else {
                    marker = "[ ]";
                }
                line = line + bed.getBedNumber() + marker + "  ";
                index = index + 1;
            }
            System.out.println(line);
        }
        System.out.println("[X] = occupied   [ ] = available");
    }
}
