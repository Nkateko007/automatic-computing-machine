package hospital;

// This is a fixed list of the 3 types of patients.
// It works like a dropdown menu that only allows these 3 choices.
public enum PatientCategory {
    INPATIENT,
    OUTPATIENT,
    EMERGENCY
}
